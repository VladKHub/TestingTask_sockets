#include "mainwindow.h"
#include "ui_mainwindow.h"



#include <QMessageBox>
#include <QIntValidator>
#include <QDateTime>
#include <QDir>
#include <QHostAddress>
#include <QNetworkInterface>
#include <QDebug>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);


    setWindowTitle("Settings Program");

    initComponents();

    setupConnections();


    loadSettings();


    updateStatus("Programm is ready. Enter value N.");

    qDebug() << "SettingsProgram: inic end";
}


MainWindow::~MainWindow()
{

    saveSettings();


    if (statusTimer && statusTimer->isActive()) {
        statusTimer->stop();
    }


    delete ui;

    qDebug() << "SettingsProgram: memory restored";
}


void MainWindow::initComponents()
{
    qDebug() << "SettingsProgram: inic component";


    settingsFilePath = QDir::homePath() + "/TestProjectSettings.ini";


    settings = new QSettings(settingsFilePath, QSettings::IniFormat, this);

    qDebug() << "Settings file:" << settingsFilePath;


    udpSocket = new QUdpSocket(this);

   //port == 12345? mb other
    const quint16 LOGIC_PROGRAM_PORT = 12345;



    qDebug() << "UDP created. Port LogicProgram:" << LOGIC_PROGRAM_PORT;

    statusTimer = new QTimer(this);
    statusTimer->setInterval(5000);

    QIntValidator *intValidator = new QIntValidator(1, 1000000, this);

    ui->nElementsLineEdit->setValidator(intValidator);


    ui->nElementsLineEdit->setPlaceholderText("Enter number from 1 to 1000000");




    ui->statusLabel->setStyleSheet("QLabel { padding: 5px; }");

    ui->statsLabel->setText("Command send: 0");

    qDebug() << "SettingsProgram: inic components";
}


void MainWindow::setupConnections()
{
    qDebug() << "SettingsProgram: connection settings.";



   // connect(ui->saveSettingsButton, &QPushButton::clicked,
            //this, &MainWindow::on_saveSettingsButton_clicked);

    //connect(ui->startButton, &QPushButton::clicked,
            //this, &MainWindow::on_startButton_clicked);


    //connect(ui->stopButton, &QPushButton::clicked,
            //this, &MainWindow::on_stopButton_clicked);


    //connect(ui->deleteButton, &QPushButton::clicked,
            //this, &MainWindow::on_deleteButton_clicked);




    //connect(ui->nElementsLineEdit, &QLineEdit::textChanged,
           // this, &MainWindow::on_nElementsLineEdit_textChanged);



    connect(statusTimer, &QTimer::timeout,
            this, &MainWindow::on_statusTimer_timeout);


    statusTimer->start();

    qDebug() << "SettingsProgram: connection works";
}



void MainWindow::loadSettings()
{
    qDebug() << "SettingsProgram: load settings";


    if (!QFile::exists(settingsFilePath)) {
        qDebug() << "File didnt find . Create new file ";
        updateStatus("Using standart numbers");
        return;
    }

    try {

        int nValue = settings->value("Settings/N", 1000).toInt();


        ui->nElementsLineEdit->setText(QString::number(nValue));


        QPoint windowPos = settings->value("Window/Position", QPoint(100, 100)).toPoint();
        QSize windowSize = settings->value("Window/Size", QSize(400, 300)).toSize();


        move(windowPos);
        resize(windowSize);


        commandStats.startCount = settings->value("Stats/StartCount", 0).toInt();
        commandStats.stopCount = settings->value("Stats/StopCount", 0).toInt();
        commandStats.deleteCount = settings->value("Stats/DeleteCount", 0).toInt();
        updateCommandStats();

        qDebug() << "Setting are ready: N =" << nValue;
        updateStatus(QString("settings are ready N = %1").arg(nValue));

    } catch (...) {
        qWarning() << "Error with settings loading!";
        updateStatus("Error with settings loading", true);
    }
}


void MainWindow::saveSettings()
{
    qDebug() << "SettingsProgram: Saving settings.";

    try {

        bool ok;
        int nValue = ui->nElementsLineEdit->text().toInt(&ok);

        if (ok && nValue > 0)
        {
            settings->setValue("Settings/N", nValue);
        }


        settings->setValue("Window/Position", pos());
        settings->setValue("Window/Size", size());


        settings->setValue("Stats/StartCount", commandStats.startCount);
        settings->setValue("Stats/StopCount", commandStats.stopCount);
        settings->setValue("Stats/DeleteCount", commandStats.deleteCount);


        settings->sync();


        if (settings->status() == QSettings::NoError) {
            qDebug() << "Succesful saving";
        } else {
            qWarning() << "Error when saving!";
        }

    } catch (...) {
        qCritical() << "Crit errror while saving";
    }
}


void MainWindow::on_saveSettingsButton_clicked()
{
    qDebug() << "SettingsProgram: Button save pushed";


    if (!validateInput())
    {
        QMessageBox::warning(this,
                             "Incorrect data",
                             "Input correct number 1<=N<=1000000");
        return;
    }


    saveSettings();


    int nValue = ui->nElementsLineEdit->text().toInt();
    QMessageBox::information(this,
                             "Settings saved",
                             QString("Value N = %1 saved in file:\n%2")
                                 .arg(nValue)
                                 .arg(settingsFilePath));

    updateStatus(QString("Settings saved . N = %1").arg(nValue));
}



void MainWindow::on_startButton_clicked()
{
    qDebug() << "SettingsProgram: START pushed";


    if (!validateInput())
    {
        updateStatus("error: incorrect N");
    }


    if (sendCommand("START"))
    {
        commandStats.startCount++;
        updateCommandStats();
        updateStatus("Command START send succesfull");


        ui->startButton->setStyleSheet("background-color: #90EE90;");
        QTimer::singleShot(500, this, [this]()
                           {
            ui->startButton->setStyleSheet("background-color: green; color: white;");
        });
    }
}


void MainWindow::on_stopButton_clicked()
{
    qDebug() << "SettingsProgram: stop pushed";


    if (sendCommand("STOP"))
    {
        commandStats.stopCount++;
        updateCommandStats();
        updateStatus("Command stop send succesfull");


        ui->stopButton->setStyleSheet("background-color: #FFB6C1;");
        QTimer::singleShot(500, this, [this]() {
            ui->stopButton->setStyleSheet("background-color: red; color: white;");
        });
    }
}


void MainWindow::on_deleteButton_clicked()
{
    qDebug() << "SettingsProgram: DELETE pushed";


    if (!validateInput())
    {
        updateStatus("Incorrect N!", true);
        return;
    }


    if (sendCommand("DELETE")) {
        commandStats.deleteCount++;
        updateCommandStats();
        updateStatus("DELETE send succesfull");


        ui->deleteButton->setStyleSheet("background-color: #FFD700;");
        QTimer::singleShot(500, this, [this]() {
            ui->deleteButton->setStyleSheet("background-color: orange; color: white;");
        });
    }
}


void MainWindow::on_nElementsLineEdit_textChanged(const QString &text)
{
    Q_UNUSED(text);


    if (validateInput()) {
        ui->nElementsLineEdit->setStyleSheet("QLineEdit { border: 2px solid green; }");
    } else {
        ui->nElementsLineEdit->setStyleSheet("QLineEdit { border: 2px solid red; }");
    }
}


void MainWindow::on_statusTimer_timeout()
{


    static int counter = 0;
    counter++;


    if (counter % 5 == 0) {
        QString time = QDateTime::currentDateTime().toString("hh:mm:ss");
        updateStatus(QString("Program is ready, time: %1. Ready to send commands.")
                         .arg(time));
    }
}



bool MainWindow::sendCommand(const QString &command)
{
    qDebug() << "SettingsProgram: Sending command" << command;


    QString nValue = ui->nElementsLineEdit->text();


    QString message;
    if (command == "STOP") {
        message = command;
    } else {

        message = QString("%1;%2").arg(command).arg(nValue);
    }


    QByteArray datagram = message.toUtf8();


    QHostAddress address = QHostAddress::LocalHost; // 127.0.0.1
    quint16 port = 12345;

    qDebug() << "Send on" << address.toString() << ":" << port;
    qDebug() << "Message:" << message;


    qint64 bytesSent = udpSocket->writeDatagram(datagram, address, port);


    if (bytesSent == -1)
    {
        QString errorMsg = QString("Error in sendind %1")
                               .arg(udpSocket->errorString());

        qCritical() << errorMsg;
        updateStatus(errorMsg, true);

        QMessageBox::critical(this,
                              "network error",
                              QString("Cant send command %1.\n"
                                      "Is working LogicProgram? \n"
                                      "Error %2")
                                  .arg(command)
                                  .arg(udpSocket->errorString()));

        return false;
    }


    QString logMsg = QString("Command '%1' send %2 bytes.")
                         .arg(message)
                         .arg(bytesSent);
    qDebug() << logMsg;


    if (ui->historyTextEdit)
    {
        QString timestamp = QDateTime::currentDateTime().toString("hh:mm:ss");
        ui->historyTextEdit->append(QString("[%1] %2").arg(timestamp).arg(message));
    }

    return true;
}


bool MainWindow::validateInput()
{
    QString text = ui->nElementsLineEdit->text();


    if (text.isEmpty()) {
        return false;
    }


    int pos = 0;
    QValidator::State state = ui->nElementsLineEdit->validator()->validate(text, pos);

    if (state != QValidator::Acceptable)
    {
        return false;
    }


    bool ok;
    int value = text.toInt(&ok);

    if (!ok || value <= 0)
    {
        return false;
    }

    return true;
}


void MainWindow::updateStatus(const QString &message, bool isError)
{

    ui->statusLabel->setText(message);


    if (isError)
    {
        ui->statusLabel->setStyleSheet(
            "QLabel { color: red; background-color: #FFE6E6; padding: 5px; border: 1px solid red; }"
            );
    }
    else
    {
        ui->statusLabel->setStyleSheet(
            "QLabel { color: green; background-color: #E6FFE6; padding: 5px; border: 1px solid green; }"
            );
    }


    qDebug() << "Status:" << message;
}



void MainWindow::updateCommandStats()
{
    int total = commandStats.startCount + commandStats.stopCount + commandStats.deleteCount;
    ui->statsLabel->setText(
        QString("Commands send %1 (START: %2, STOP: %3, DELETE: %4)")
            .arg(total)
            .arg(commandStats.startCount)
            .arg(commandStats.stopCount)
            .arg(commandStats.deleteCount)
        );
}
