#ifndef MAINWINDOW_H
#define MAINWINDOW_H



#include <QMainWindow>
#include <QUdpSocket>
#include <QSettings>
#include <QTimer>


QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    explicit MainWindow(QWidget *parent = nullptr);


    ~MainWindow();

private slots:

    void on_saveSettingsButton_clicked();

    void on_startButton_clicked();

    void on_stopButton_clicked();

    void on_deleteButton_clicked();

    void on_nElementsLineEdit_textChanged(const QString &text);

    void on_statusTimer_timeout();



private:


    Ui::MainWindow *ui;
    QUdpSocket *udpSocket;
    QSettings *settings;
    QTimer *statusTimer;
    QString settingsFilePath;


    struct
    {
        int startCount = 0;
        int stopCount = 0;
        int deleteCount = 0;
    } commandStats;


    void initComponents();

    void setupConnections();

    void loadSettings();

    void saveSettings();

    bool sendCommand(const QString &command);

    bool validateInput();

    void updateStatus(const QString &message, bool isError = false);

    void updateCommandStats();
};

#endif
