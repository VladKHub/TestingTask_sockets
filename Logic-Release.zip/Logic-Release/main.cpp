#include <QCoreApplication>
#include <QUdpSocket>
#include <QLocalServer>
#include <QLocalSocket>
#include <QVector>
#include <QThread>
#include <QMutex>
#include <QDateTime>
#include <QRandomGenerator>
#include <QElapsedTimer>
#include <iostream>

//protect container
QMutex containerMutex;

//protect logs
QMutex logMutex;

//stop flag
bool stopRequested = false;

//delete flag
bool deleteRequested = false;

//container (std::vector? mb)
QVector<bool> boolContainer;

//to work with Results
QLocalServer *localServer = nullptr;

//channel to get/give info
QLocalSocket *resultsSocket = nullptr;



//send mess to results
void sendToResults(const QString &message)
{
    if (resultsSocket && resultsSocket->state() == QLocalSocket::ConnectedState)
    {
        QByteArray data = message.toUtf8() + "\n";
        resultsSocket->write(data);
        resultsSocket->flush();
    }
}


QString getCurrentThreadIdAsString()
{
    QThread* currentThread = QThread::currentThread();
    quintptr threadId = reinterpret_cast<quintptr>(currentThread);
    return QString::number(threadId);
}



//creating and sending logs
void logEvent(const QString &event)
{
    QMutexLocker locker(&logMutex);


    QDateTime now = QDateTime::currentDateTime();
    QString timestamp = now.toString("yyyy-MM-dd hh:mm:ss");


    qint64 microseconds = now.time().msecsSinceStartOfDay() * 1000;
    QString timeWithMicro = QString("%1.%2")
                                .arg(timestamp)
                                .arg(microseconds % 1000000, 6, 10, QChar('0'));


    qint64 pid = QCoreApplication::applicationPid();
    QString threadId = getCurrentThreadIdAsString();

    //log string
    QString logMessage = QString("%1 | PID: %2 | Thread: %3 | %4")
                             .arg(timeWithMicro)
                             .arg(pid)
                             .arg(threadId)
                             .arg(event);


    std::cout << logMessage.toStdString() << std::endl;


    sendToResults(logMessage);
}





//writing bools in container
class WriterThread : public QThread
{
    Q_OBJECT

public:

    explicit WriterThread(int n, QObject *parent = nullptr)
        : QThread(parent), nElements(n)
    {
        logEvent(QString("Created thread for %1 elements").arg(n));
    }



protected:


    //base method
    void run() override
    {

        logEvent("START WRITING");

        QElapsedTimer timer;
        timer.start();

        for (int i = 0; i < nElements; ++i)
        {

            if (stopRequested) {
                logEvent("Writing has interrupted by STOP");
                break;
            }

            //random
            int index = QRandomGenerator::global()->bounded(boolContainer.size());


            bool value = QRandomGenerator::global()->bounded(2);


            {
                QMutexLocker locker(&containerMutex);
                boolContainer[index] = value;
            }


            if (i % 100 == 0)
            {
                msleep(1);
                logEvent(QString("Writed %1 in %2 elements").arg(i).arg(nElements));
            }


            if (i > 0 && i % 100 == 0)
            {
                qint64 elapsed = timer.elapsed();
                logEvent(QString("Writing progress: %1 elements in %2 ms")
                             .arg(i).arg(elapsed));
            }
        }


        qint64 totalTime = timer.elapsed();
        logEvent(QString("STOP WRITING | Total elements %1 | Time %2 ms")
                     .arg(nElements).arg(totalTime));
    }

private:
    int nElements; //N
};




//reading from container
class ReaderThread : public QThread
{
    Q_OBJECT

public:
    explicit ReaderThread(int n, QObject *parent = nullptr)
        : QThread(parent), nElements(n)
    {
        logEvent(QString("Created thread for reading %1 elements").arg(n));
    }



protected:
    void run() override {

        logEvent("READING START");

        QElapsedTimer timer;
        timer.start();

        int readSuccess = 0;

        for (int i = 0; i < nElements; ++i)
        {

            if (stopRequested)
            {
                logEvent("Reading interrupted by STOP");
                break;
            }


            int index = QRandomGenerator::global()->bounded(boolContainer.size());

            bool value = false;


            {
                QMutexLocker locker(&containerMutex);
                if (index >= 0 && index < boolContainer.size())
                {
                    value = boolContainer[index];
                    readSuccess++;
                }
            }


            Q_UNUSED(value);


            if (i % 100 == 0)
            {
                msleep(1);
                logEvent(QString("Read %1 from %2 elements").arg(i).arg(nElements));
            }


            if (i > 0 && i % 100 == 0)
            {
                qint64 elapsed = timer.elapsed();
                logEvent(QString("Reading process %1 elements in %2 ms")
                             .arg(i).arg(elapsed));
            }
        }


        qint64 totalTime = timer.elapsed();
        logEvent(QString("STOP READING | SUCSFL REDNG %1/%2 | TIME %3 ms")
                     .arg(readSuccess).arg(nElements).arg(totalTime));
    }

private:
    int nElements;
};






class LogicController : public QObject
{
    Q_OBJECT

public:
    LogicController(QObject *parent = nullptr) : QObject(parent)
    {
        logEvent("INICial LogicController...");
        setupUdpSocket();
        setupLocalServer();
    }



private:
    QUdpSocket *udpSocket = nullptr;
    WriterThread *writerThread = nullptr;
    ReaderThread *readerThread = nullptr;


    void setupUdpSocket()
    {
        udpSocket = new QUdpSocket(this);

        //  localhost:12345
        if (!udpSocket->bind(QHostAddress::LocalHost, 12345))
        {
            logEvent("ERROR: couldnt connect to  12345");
        }
        else
        {
            logEvent("UDP : 127.0.0.1:12345");
            logEvent("waiting for SettingsProgram...");
        }


        connect(udpSocket, &QUdpSocket::readyRead,
                this, &LogicController::processCommands);
    }


    void setupLocalServer()
    {
        localServer = new QLocalServer(this);


        QLocalServer::removeServer("test_results_socket");


        if (!localServer->listen("test_results_socket"))
        {
            logEvent("ERROR: cant create server");
        }
        else
        {
            logEvent("server has been started: test_results_socket");
            logEvent("Оwaiting for connection ResultsProgram...");
        }


        connect(localServer, &QLocalServer::newConnection,
                this, &LogicController::handleNewConnection);
    }

private slots:

    void processCommands()
    {
        while (udpSocket->hasPendingDatagrams())
        {

            QByteArray datagram;
            datagram.resize(udpSocket->pendingDatagramSize());

            QHostAddress sender;
            quint16 senderPort;

            udpSocket->readDatagram(datagram.data(), datagram.size(),
                                    &sender, &senderPort);


            QString command = QString::fromUtf8(datagram);
            logEvent(QString("Got command from %1:%2 - %3")
                         .arg(sender.toString()).arg(senderPort).arg(command));


            QStringList parts = command.split(';');
            if (parts.size() == 2)
            {
                QString cmd = parts[0];
                bool ok;
                int n = parts[1].toInt(&ok);

                if (!ok || n <= 0)
                {
                    logEvent("ERROR: incorrect N " + parts[1]);
                    continue;
                }


                if (cmd == "START")
                {
                    logEvent(QString("Run START with N=%1").arg(n));
                    startAlgorithm(n);
                }
                else if (cmd == "STOP")
                {
                    logEvent("Run STOP");
                    stopAlgorithm();
                }
                else if (cmd == "DELETE")
                {
                    logEvent(QString("Run DELETE for %1 elements").arg(n));
                    deleteAlgorithm(n);
                }
                else {
                    logEvent("ERROR: unknown command" + cmd);
                }
            }
            else
            {
                logEvent("ERROR incorrect formof command " + command);
                logEvent("EXPECTS: command;N ");
            }
        }
    }


    void handleNewConnection()
    {
        resultsSocket = localServer->nextPendingConnection();
        if (resultsSocket)
        {
            logEvent("ResultsProgram connected!");


            connect(resultsSocket, &QLocalSocket::disconnected,
                    resultsSocket, &QLocalSocket::deleteLater);


            sendToResults("=== CONNECTING К LOGICPROGRAM SUCCSESFULL ===");
            sendToResults(QString("PID process: %1")
                              .arg(QCoreApplication::applicationPid()));
            sendToResults("Ready for getting commands from SettingsProgram");
        }
    }

private:

    void startAlgorithm(int n)
    {
        logEvent(QString("=== STARTING READING-WRITING ==="));
        logEvent(QString("Count N: %1").arg(n));


        stopAlgorithm();


        {
            QMutexLocker locker(&containerMutex);


            boolContainer.clear();

            int containerSize = n * 2;
            boolContainer.resize(containerSize);


            std::fill(boolContainer.begin(), boolContainer.end(), false);

            logEvent(QString("Container created | Size: %1 elements")
                         .arg(containerSize));
        }


        stopRequested = false;
        deleteRequested = false;


        writerThread = new WriterThread(n, this);
        readerThread = new ReaderThread(n, this);


        connect(writerThread, &WriterThread::finished,
                writerThread, &QObject::deleteLater);
        connect(readerThread, &ReaderThread::finished,
                readerThread, &QObject::deleteLater);


        logEvent("Run threads ");
        writerThread->start();
        readerThread->start();

        logEvent("Alghorythm running");
    }


    void stopAlgorithm()
    {
        logEvent("=== STOP ALGORYTHM ===");


        stopRequested = true;



        if (writerThread && writerThread->isRunning())
        {
            logEvent("Waiting for writing thread");
            writerThread->wait(5000);
            if (writerThread->isRunning()) {
                logEvent("5 seconds wasnt enough to end writing");
            }
        }


        if (readerThread && readerThread->isRunning())
        {
            logEvent("Waiting for reading thread");
            readerThread->wait(5000);
            if (readerThread->isRunning()) {
                logEvent("5 seconds wasnt enough to end reading");
            }
        }

        logEvent("all threads end work");


        sendToResults("=== ALGORYTHM HAS STOPPED ===");
        sendToResults(QString("Size of comtainer: %1 elements")
                          .arg(boolContainer.size()));
    }


    void deleteAlgorithm(int n)
    {
        logEvent("=== DELETE ALGORYTHM ===");

        QMutexLocker locker(&containerMutex);

        if (boolContainer.isEmpty())
        {
            logEvent("Container is emty now.");
            return;
        }


        int elementsToDelete = qMin(n, boolContainer.size());


        boolContainer.remove(0, elementsToDelete);

        logEvent(QString("Deleted %1 elements").arg(elementsToDelete));
        logEvent(QString("There are %1 elem left in container")
                     .arg(boolContainer.size()));


        sendToResults(QString("Deleted: %1").arg(elementsToDelete));
        sendToResults(QString(" %1 elem left").arg(boolContainer.size()));
    }
};



int main(int argc, char *argv[])
{

    QCoreApplication a(argc, argv);


    a.setApplicationName("LogicProgram");
    a.setApplicationVersion("1.0");


    std::cout << "========================================" << std::endl;
    std::cout << "main.cpp running" << std::endl;
    std::cout << "Name: " << a.applicationName().toStdString() << std::endl;
    std::cout << "version: " << a.applicationVersion().toStdString() << std::endl;
    std::cout << "PID: " << a.applicationPid() << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << std::endl;

    logEvent("=== MAIN PROGRAMM ===");
    logEvent("ready to work");
    logEvent("Waiting commands from UDP:12345");
    logEvent("waiting for connection");


    LogicController controller;


    int result = a.exec();

    logEvent("Program end with code " + QString::number(result));
    return result;
}


#include "main.moc"
