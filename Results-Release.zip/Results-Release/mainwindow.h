#ifndef MAINWINDOW_H
#define MAINWINDOW_H



#include <QMainWindow>
#include <QLocalSocket>
#include <QStandardItemModel>
#include <QElapsedTimer>
#include <QTimer>


QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_connectButton_clicked();

    void on_clearButton_clicked();

    void on_filterComboBox_currentIndexChanged(int index);

    void on_autoScrollCheckBox_stateChanged(int state);

    void onSocketReadyRead();

    void onSocketConnected();

    void onSocketDisconnected();

    void onSocketError(QLocalSocket::LocalSocketError error);


    void on_updateTimer_timeout();

    void on_tableView_doubleClicked(const QModelIndex &index);


private:


    Ui::MainWindow *ui;
    QLocalSocket *localSocket;
    QStandardItemModel *tableModel;
    QTimer *updateTimer;


    struct Statistics {
        int totalEvents = 0;
        int startEvents = 0;
        int stopEvents = 0;
        int writeEvents = 0;
        int readEvents = 0;
        int errorEvents = 0;
        qint64 firstEventTime = 0;
        qint64 lastEventTime = 0;
    } statistics;

    bool autoScrollEnabled = true;
    QString currentFilter = "Все";




    void initComponents();


    void setupConnections();


    void setupTableModel();


    bool parseLogLine(const QString &logLine,
                      QString &timestamp,
                      QString &pid,
                      QString &threadId,
                      QString &event);


    void addLogEntry(const QString &timestamp,
                     const QString &pid,
                     const QString &threadId,
                     const QString &event);


    void updateStatistics(const QString &event);


    void updateStatusBar();


    void updateStatisticsDisplay();


    void applyFilter(const QString &filter);


    void saveLogToFile();


    void loadLogFromFile();
};

#endif
