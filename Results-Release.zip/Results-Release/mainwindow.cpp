#include "mainwindow.h"
#include "ui_mainwindow.h"


#include <QDateTime>
#include <QMessageBox>
#include <QFileDialog>
#include <QTextStream>
#include <QFile>
#include <QDir>
#include <QDebug>
#include <QHeaderView>
#include <QSortFilterProxyModel>
#include <QClipboard>
#include <QApplication>
#include <QColor>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , localSocket(new QLocalSocket(this))
    , tableModel(new QStandardItemModel(this))
    , updateTimer(new QTimer(this))
{

    ui->setupUi(this);


    setWindowTitle("Result program");


    initComponents();


    setupConnections();


    setupTableModel();


    updateStatusBar();

    qDebug() << "ResultsProgram: inic end";
}


MainWindow::~MainWindow()
{

    if (localSocket->state() == QLocalSocket::ConnectedState) {
        localSocket->disconnectFromServer();
    }


    updateTimer->stop();


    delete ui;
    qDebug() << "ResultsProgram: resources released";
}


void MainWindow::initComponents()
{
    qDebug() << "ResultsProgram: component inicialized";




    statusBar()->showMessage("Ready to connect to LogicProgram");


    updateTimer->setInterval(1000);
    updateTimer->start();




    ui->filterComboBox->addItem("All Events");
    ui->filterComboBox->addItem("Only Ready/Pause");
    ui->filterComboBox->addItem("Only Writing");
    ui->filterComboBox->addItem("Only Reading");
    ui->filterComboBox->addItem("Only Errors");


    currentFilter = "All Events";

    qDebug() << "ResultsProgram: inic components";
}



void MainWindow::setupConnections()
{
    qDebug() << "ResultsProgram: connection settings.";



    connect(localSocket, &QLocalSocket::readyRead,
            this, &MainWindow::onSocketReadyRead);


    connect(localSocket, &QLocalSocket::connected,
            this, &MainWindow::onSocketConnected);


    connect(localSocket, &QLocalSocket::disconnected,
            this, &MainWindow::onSocketDisconnected);


    connect(localSocket, &QLocalSocket::errorOccurred,
            this, &MainWindow::onSocketError);



    connect(updateTimer, &QTimer::timeout,
            this, &MainWindow::on_updateTimer_timeout);





    qDebug() << "ResultsProgram: Connection is ready";
}



void MainWindow::setupTableModel()
{
    qDebug() << "ResultsProgram: Table settings.";


    QStringList headers;
    headers << "Timw (ms)"
            << "PID"
            << "ID thread"
            << "Event"
            << "Information";

    tableModel->setHorizontalHeaderLabels(headers);




    ui->tableView->setModel(tableModel);


    ui->tableView->setAlternatingRowColors(true);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setSortingEnabled(true);


    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->setColumnWidth(0, 180);
    ui->tableView->setColumnWidth(1, 100);
    ui->tableView->setColumnWidth(2, 100);
    ui->tableView->setColumnWidth(3, 250);

    ui->tableView->setContextMenuPolicy(Qt::CustomContextMenu);

    qDebug() << "ResultsProgram: Table is ready. Columns:" << tableModel->columnCount();
}



void MainWindow::on_connectButton_clicked()
{
    qDebug() << "ResultsProgram: Connect button clicked";


    if (localSocket->state() == QLocalSocket::ConnectedState) {

        qDebug() << "Disconnect from LogicProgram...";
        localSocket->disconnectFromServer();

        if (localSocket->state() == QLocalSocket::UnconnectedState ||
            localSocket->waitForDisconnected(1000)) {
            ui->connectButton->setText("Connect");
            statusBar()->showMessage("Disconnect from LogicProgram");
            qDebug() << "Disconnect succesfull";
        }
    } else {

        qDebug() << "Connection к LogicProgram...";


        QString serverName = "test_results_socket";


        localSocket->connectToServer(serverName);


        if (localSocket->waitForConnected(2000))
        {
            ui->connectButton->setText("Disconnect");
            statusBar()->showMessage("Connected to LogicProgram");
            qDebug() << "Succesfull connection";
        } else {
            QString errorMsg = QString("Connection Error: %1").arg(localSocket->errorString());
            statusBar()->showMessage(errorMsg);
            QMessageBox::warning(this, "Connection Error",
                                 QString("Couldnt connect to LogicProgram.\n"
                                         "Check that LogicProgram is running.\n"
                                         "Error: %1").arg(localSocket->errorString()));
            qDebug() << "Connection Error:" << localSocket->errorString();
        }
    }
}


void MainWindow::on_clearButton_clicked()
{
    qDebug() << "ResultsProgram: Clear Table";


    int result = QMessageBox::question(this, "Table Clearing",
                                       "Are you ready to clear all Table?\n"
                                       "All data will be delete",
                                       QMessageBox::Yes | QMessageBox::No,
                                       QMessageBox::No);

    if (result == QMessageBox::Yes) {

        tableModel->removeRows(0, tableModel->rowCount());


        statistics = Statistics();


        updateStatisticsDisplay();
        updateStatusBar();

        statusBar()->showMessage("Table cleared", 3000);
        qDebug() << "Table cleared";
    }
}



void MainWindow::onSocketReadyRead()
{

    while (localSocket->canReadLine()) {

        QByteArray lineData = localSocket->readLine();
        QString logLine = QString::fromUtf8(lineData).trimmed();


        if (logLine.isEmpty()) {
            continue;
        }




        QString timestamp, pid, threadId, event;
        if (parseLogLine(logLine, timestamp, pid, threadId, event)) {

            addLogEntry(timestamp, pid, threadId, event);


            updateStatistics(event);
        } else {

            qWarning() << "Couldnt parse the data:" << logLine;
            addLogEntry(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz"),
                        "?", "?", logLine);
            statistics.errorEvents++;
        }
    }


    updateStatisticsDisplay();
}


bool MainWindow::parseLogLine(const QString &logLine,
                              QString &timestamp,
                              QString &pid,
                              QString &threadId,
                              QString &event)
{

    QStringList parts = logLine.split(" | ");


    if (parts.size() < 4) {
        return false;
    }


    timestamp = parts[0].trimmed();


    QString pidPart = parts[1].trimmed();
    if (pidPart.startsWith("PID:")) {
        pid = pidPart.mid(4).trimmed();
    } else {
        pid = pidPart;
    }


    QString threadPart = parts[2].trimmed();
    if (threadPart.startsWith("Thread:")) {
        threadId = threadPart.mid(7).trimmed();
    } else {
        threadId = threadPart;
    }


    event = parts[3].trimmed();
    for (int i = 4; i < parts.size(); ++i) {
        event += " | " + parts[i].trimmed();
    }

    return true;
}



void MainWindow::addLogEntry(const QString &timestamp,
                             const QString &pid,
                             const QString &threadId,
                             const QString &event)
{

    QList<QStandardItem*> rowItems;


    QStandardItem *timeItem = new QStandardItem(timestamp);
    timeItem->setData(timestamp, Qt::ToolTipRole);
    rowItems.append(timeItem);


    QStandardItem *pidItem = new QStandardItem(pid);
    pidItem->setTextAlignment(Qt::AlignCenter);
    rowItems.append(pidItem);


    QStandardItem *threadItem = new QStandardItem(threadId);
    threadItem->setTextAlignment(Qt::AlignCenter);
    rowItems.append(threadItem);


    QStandardItem *eventItem = new QStandardItem(event);


    if (event.contains("BEGIN", Qt::CaseInsensitive)) {
        eventItem->setBackground(QColor(220, 255, 220));
        statistics.startEvents++;
    } else if (event.contains("PAUSE", Qt::CaseInsensitive)) {
        eventItem->setBackground(QColor(255, 220, 220));
        statistics.stopEvents++;
    } else if (event.contains("WRITING", Qt::CaseInsensitive) ||
               event.contains("WRITED", Qt::CaseInsensitive)) {
        eventItem->setBackground(QColor(220, 220, 255));
        statistics.writeEvents++;
    } else if (event.contains("READING", Qt::CaseInsensitive) ||
               event.contains("READED", Qt::CaseInsensitive)) {
        eventItem->setBackground(QColor(255, 255, 220));
        statistics.readEvents++;
    } else if (event.contains("ERROR", Qt::CaseInsensitive) ||
               event.contains("ERROR", Qt::CaseInsensitive)) {
        eventItem->setBackground(QColor(255, 200, 200));
        statistics.errorEvents++;
    }

    rowItems.append(eventItem);


    rowItems.append(new QStandardItem(""));


    tableModel->appendRow(rowItems);


    statistics.totalEvents++;


    QDateTime currentTime = QDateTime::currentDateTime();
    qint64 currentMs = currentTime.toMSecsSinceEpoch();

    if (statistics.firstEventTime == 0) {
        statistics.firstEventTime = currentMs;
    }
    statistics.lastEventTime = currentMs;


    if (autoScrollEnabled) {
        ui->tableView->scrollToBottom();
    }


}


void MainWindow::updateStatistics(const QString &event)
{


    Q_UNUSED(event);
}



void MainWindow::updateStatisticsDisplay()
{

    ui->totalEventsLabel->setText(QString::number(statistics.totalEvents));
    ui->startEventsLabel->setText(QString::number(statistics.startEvents));
    ui->stopEventsLabel->setText(QString::number(statistics.stopEvents));
    ui->writeEventsLabel->setText(QString::number(statistics.writeEvents));
    ui->readEventsLabel->setText(QString::number(statistics.readEvents));
    ui->errorEventsLabel->setText(QString::number(statistics.errorEvents));


    if (statistics.firstEventTime > 0 && statistics.lastEventTime > 0) {
        qint64 durationMs = statistics.lastEventTime - statistics.firstEventTime;
        QString durationStr = QString("%1.%2 sec")
                                  .arg(durationMs / 1000)
                                  .arg(durationMs % 1000, 3, 10, QChar('0'));
        ui->durationLabel->setText(durationStr);
    } else {
        ui->durationLabel->setText("0.000 sec");
    }
}


void MainWindow::onSocketConnected()
{
    qDebug() << "ResultsProgram: Connection  to LogicProgram is ready";

    // Обновляем UI
    ui->connectButton->setText("Disconnect");
    ui->connectButton->setStyleSheet("background-color: #90EE90;");


    statusBar()->showMessage("Connected to LogicProgram. Waiting for data");


    QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz");
    addLogEntry(timestamp,
                QString::number(QCoreApplication::applicationPid()),
                "0",
                "=== CONNECTION TO LOGICPROGRAM IS READY ===");
}


void MainWindow::onSocketDisconnected()
{
    qDebug() << "ResultsProgram: Disconnect from LogicProgram";


    ui->connectButton->setText("Connect");
    ui->connectButton->setStyleSheet("");


    statusBar()->showMessage("Disconnect from LogicProgram");


    QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz");
    addLogEntry(timestamp,
                QString::number(QCoreApplication::applicationPid()),
                "0",
                "=== DISCONNECT FROM LOGICPROGRAM ===");
}


void MainWindow::onSocketError(QLocalSocket::LocalSocketError error)
{
    Q_UNUSED(error);

    QString errorMsg = QString("Socket error: %1").arg(localSocket->errorString());
    qWarning() << errorMsg;


    QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz");
    addLogEntry(timestamp,
                QString::number(QCoreApplication::applicationPid()),
                "0",
                "ERROR: " + localSocket->errorString());

    statusBar()->showMessage(errorMsg);
}


void MainWindow::on_updateTimer_timeout()
{

    updateStatusBar();


    static int tickCounter = 0;
    tickCounter++;


    if (tickCounter % 10 == 0 && statistics.totalEvents > 0)
    {

    }
}



void MainWindow::updateStatusBar()
{
    QString status;

    if (localSocket->state() == QLocalSocket::ConnectedState) {
        status = QString("Connected | Events: %1 | Time: %2")
                     .arg(statistics.totalEvents)
                     .arg(QDateTime::currentDateTime().toString("hh:mm:ss"));
    } else {
        status = QString("Not connected | Events: %1")
                     .arg(statistics.totalEvents);
    }

    statusBar()->showMessage(status);
}


void MainWindow::on_filterComboBox_currentIndexChanged(int index)
{
    QString filterText = ui->filterComboBox->itemText(index);
    currentFilter = filterText;

    qDebug() << "ResultsProgram: Filter use:" << filterText;


    applyFilter(filterText);
}


void MainWindow::applyFilter(const QString &filter)
{

    for (int row = 0; row < tableModel->rowCount(); ++row) {
        QStandardItem *eventItem = tableModel->item(row, 3);
        QString event = eventItem->text();

        bool showRow = false;

        if (filter == "All events") {
            showRow = true;
        } else if (filter == "Only BEGIN/PAUSE") {
            showRow = event.contains("BEGIN", Qt::CaseInsensitive) ||
                      event.contains("PAUSE", Qt::CaseInsensitive);
        } else if (filter == "Only WRITING") {
            showRow = event.contains("WRITING", Qt::CaseInsensitive) ||
                      event.contains("WRITED", Qt::CaseInsensitive);
        } else if (filter == "Only READING") {
            showRow = event.contains("READING", Qt::CaseInsensitive) ||
                      event.contains("READ", Qt::CaseInsensitive);
        } else if (filter == "Only ERRORS") {
            showRow = event.contains("ERROR", Qt::CaseInsensitive) ||
                      event.contains("ERROR", Qt::CaseInsensitive);
        }


        ui->tableView->setRowHidden(row, !showRow);
    }
}


void MainWindow::on_autoScrollCheckBox_stateChanged(int state)
{
    autoScrollEnabled = (state == Qt::Checked);

    if (autoScrollEnabled) {
        qDebug() << "Autoscrolling is on";
        statusBar()->showMessage("Autoscrolling is on", 2000);
    } else {
        qDebug() << "Autoscrolling is off";
        statusBar()->showMessage("Autoscrolling is off", 2000);
    }
}



void MainWindow::on_tableView_doubleClicked(const QModelIndex &index)
{
    if (!index.isValid()) {
        return;
    }


    QString time = tableModel->item(index.row(), 0)->text();
    QString pid = tableModel->item(index.row(), 1)->text();
    QString threadId = tableModel->item(index.row(), 2)->text();
    QString event = tableModel->item(index.row(), 3)->text();


    QString details = QString(
                          "Event details:\n\n"
                          "Time: %1\n"
                          "PID process: %2\n"
                          "ID thread: %3\n"
                          "Event: %4\n\n"
                          "Copy to clipboard"
                          ).arg(time).arg(pid).arg(threadId).arg(event);


    int result = QMessageBox::information(this, "Event details", details,
                                          QMessageBox::Yes | QMessageBox::No);

    if (result == QMessageBox::Yes) {

        QString clipboardText = QString("%1 | PID: %2 | Thread: %3 | %4")
                                    .arg(time).arg(pid).arg(threadId).arg(event);
        QApplication::clipboard()->setText(clipboardText);
        statusBar()->showMessage("Data copied to clipboard", 2000);
    }
}

